var mongoose = require('mongoose');
var WpnList;
var WpnSchema;
var AmmList;
var AmmSchema;
/// this file must be include AFTER mongoose.connect


function init()
{
    WpnSchema = mongoose.Schema(
    {
        name:String,
        cal:String,
        description:String,
        amount:Number,
        price:Number
    });
    WpnList = mongoose.model('Weapon',WpnSchema);

    AmmSchema = mongoose.Schema(
    {
        name:String,
        cal:String,
        amount:Number,
        price:Number
    });
    AmmList = mongoose.model('Ammo',AmmSchema);
}

function addobj(w, name, cal, amount, price, descr, callback, errf)
{
    if(w) WpnList.findOne({ 'name':name }, function(err, obj)
    {
        if(err||obj) errf();
        else
        {
            Obj = new WpnList();
            Obj.name = name;
            Obj.cal = cal;
            Obj.amount = amount;
            Obj.price = price;
            Obj.description = descr;
            Obj.save(function(err)
            {
                if(err) throw err;
                callback();
            });
        }
    });
    else AmmList.findOne({ 'name':name }, function(err, obj)
    {
        if(err) return done(err);
        if(obj) return done(null, false, 'That ammo type already exist.');
        else
        {
            Obj = new AmmList();
            Obj.name = name;
            Obj.cal = cal;
            Obj.amount = amount;
            Obj.price = price;
            Obj.description = descr;
            Obj.save(function(err)
            {
                if(err) throw err;
                callback();
            });
        }
    });
}

function addamount(w, name, num, callback, errf)
{
    console.log("============="+name+"===============");
    num = parseInt(num);
    if(num<=0) errf();
    if(w) WpnList.findOne({ 'name':name }, function(err,obj)
    { if(err) errf(); obj.update({ amount: obj.amount+num },callback); });
    else AmmList.findOne({ 'name':name }, function(err,obj)
    { if(err) errf(); obj.update({ amount: obj.amount+num },callback); });
}
init();
module.exports =
{
    init:init,
    addobj:addobj,
    addamount:addamount,
    wpnList:WpnList,
    ammList:AmmList
};
