var router = require('express').Router();
var passport = require('passport');
var accounts = require('./accounts');
var db = require('./db');
var fs = require('fs');

router.get('/', function(req, res, next){ res.render('yndex', { title: 'New weapon shop', user:isLoggedIn2(req) }); });
router.get('/yndex', function(req, res, next){ res.render('yndex', { title: 'New weapon shop', user:isLoggedIn2(req) }); });
router.get('/shop', function(req, res)
{
    db.wpnList.find({},function(err,l)
    {
        db.ammList.find({},function(err,l2)
        { res.render('shop', { user:isLoggedIn2(req),WpnList:l,AmmList:l2 }); });
    });
});

router.get('/login', function(req, res, next){ res.render('login',{ message:null }); });
router.get('/signup', function(req, res){ res.render('signup',{ message:null }); });
router.get('/logout', function(req, res){ req.logout(); res.redirect('/'); });
router.get('/list', function(req, res)
{
    usr = isLoggedIn2(req);
    if(usr && usr.mark<1)
        accounts.list.find({},function(err,l)
        {
            res.render('list', {list:l,user:usr});
            if(err) throw err;
        });
    else res.redirect('/');
});
router.get('/shopmng', function(req, res)
{
    usr = isLoggedIn2(req);
    if(usr && usr.mark<2)
    {
        db.wpnList.find({},function(err,l)
        {
            db.ammList.find({},function(err,l2)
            { res.render('shopmng', {user:usr,WpnList:l,AmmList:l2}); });
        });
    }
    else res.redirect('/');
});

router.post('/login',  passport.authenticate('local-login',{ successRedirect: '/yndex', failureRedirect: '/login' }));
router.post('/signup', function(req, res, next)
{
    passport.authenticate('local-signup', function(err, user, info)
    {
        if(info) console.log(err+"-"+user+"-"+info.message);
        if(user)
            req.logIn(user, function(err)
            {
                if(err) return next(err);
                else res.redirect('/');
            });
        if(!user) res.send({ success: false, response: 'Authentication Failed',msg: 'founded user'});
        if(err) res.send({ success: false, response: 'Authentication failed',msg: 'not known err' })
    })(req, res, next);
});
router.post('/list', function(req, res, next)
{
    usr = isLoggedIn2(req);
    if(usr && usr.mark<1)
    {
        accounts.grade(req.body.id,req.body.action,function(err)
        {
            accounts.list.find({},function(err,l)
            {
                res.render('list', {list:l,user:usr});
                if(err) throw err;
            });
        });
    }
    else res.redirect('/');
});
router.post('/shopmng', function(req,res)
{
    findproducts = function()
    {
        db.wpnList.find({},function(err,l)
        {
            db.ammList.find({},function(err,l2)
            { res.render('shopmng', {user:usr,WpnList:l,AmmList:l2}); });
        });
    }

    usr = isLoggedIn2(req);
    if(usr && usr.mark<2)
    {
        console.log(req.body.aamodel);
        if(req.body.type=='1')
            db.addobj(true,req.body.awmodel, req.body.awcal,req.body.awamount,req.body.awprice,req.body.awdescr,findproducts,function(){res.redirect('/shopmng');});
        else if(req.body.type=='2')
            db.addobj(false,req.body.aamodel, req.body.aacal,req.body.aaamount,req.body.aaprice,'',findproducts,function(){res.redirect('/shopmng');});
        else if(req.body.type=='3')
            db.addamount(true,req.body.uwmodel, req.body.uwamount, findproducts, function(){ res.redirect('/shopmng'); });
        else if(req.body.type=='4')
            db.addamount(false,req.body.uamodel, req.body.uaamount, findproducts, function(){ res.redirect('/shopmng'); });
        else res.redirect('/');
    }
    else res.redirect('/');
});

router.get('/css', function(req, res, next){ return sendFile('library/styles.css',res); });
router.get('/jquery', function(req, res, next){ return sendFile('library/jquery-3.1.1.js',res); });
router.get('/lib/*', function(req,res){ sendFile('lib/'+req.params[0],res,true); });
router.get('/images/*', function(req,res){ sendFile('images/'+req.params[0],res); });

module.exports = router;



function sendFile(src,res,txt=false)
{
    fs.readFile(src, function(err, data)
    {
        if(err) { res.send(""); return console.error(err); }
        if(txt) res.send(data.toString());
            else res.send(data);
    });
}

function isLoggedIn2(req){ return req.isAuthenticated()?req.user:null; }
function isLoggedIn(req, res, next)
{
    if(req.isAuthenticated()) return next();
    res.redirect('/');
}
