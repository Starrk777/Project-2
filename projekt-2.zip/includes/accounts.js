var mongoose = require('mongoose');
var LocalStrategy = require('passport-local').Strategy;
var bcrypt   = require('bcrypt-nodejs');

// tworze schemat obiektow do bd
var AccSchema = mongoose.Schema(
{ local:{ name: String, email: String, password: String }, mark:Number });

AccSchema.methods.generateHash = function(password)
{ return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null); };

AccSchema.methods.validPassword = function(password)
{ return bcrypt.compareSync(password, this.local.password); };

var List = mongoose.model('User', AccSchema);


function Grade(email,gr,callback)
{
    if(gr!='upgrade' && gr!='downgrade') return;
    List.findOne({ 'local.email':email },function(err,usr)
    {
        if(usr)
        {
            usr.mark = usr.mark + (gr=='upgrade'?-1:1);
            usr.save(callback);
        }
    });
}


function init(passport)
{
    process.stdout.write('initializing: accounts database...');

    passport.serializeUser(function(user, done){ done(null, user.id);});
    passport.deserializeUser(function(id, done){ List.findById(id, function(err, user){ done(err, user); }); });

    passport.use('local-signup', new LocalStrategy({usernameField: 'email', passwordField: 'password', passReqToCallback: true},
        function(req, email, password, done)
        {
            process.nextTick(function()
            {
                List.find({}, function(err,l)
                {
                    if(err) return done(err);
                    var b=false;
                    for(var a=0; a<l.length; a++) if(l[a].local.email==email) { b = true; break; }
                    if(b) return done(null, false, 'That email is already taken.');
                    else
                    {
                        var mark = (l.length==0?0:2);
                        var NUser = new List();
                        NUser.local.email = email;
                        NUser.local.password = NUser.generateHash(password);
                        NUser.mark = mark;
                        NUser.save(function(err)
                        {
                            if(err) throw err;
                            return done(null, NUser);
                        });
                    }
                });
            });
        }));

    passport.use('local-login', new LocalStrategy(
    {
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true,
    },
    function(req, email, password, done)
    {
        List.findOne({ 'local.email':  email }, function(err, user)
        {
            if(err) return done(err);
            if(!user) return done(null, false, 'No user found.');
            if(!user.validPassword(password)) return done(null, false, 'Oops! Wrong password.');
            return done(null, user);
        });
    }));
    console.log('    compleated!');
}
//eksportuje go wraz z inicjalizacja passportu
module.exports =
{
    list:List,
    init:init,
    grade:Grade
};
// use with accounts.init();
//          accounts.list.findOne
