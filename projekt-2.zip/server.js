var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var passport = require('passport');
var mongoose = require('mongoose');
var session = require('express-session');
var router = require('./includes/router');
var accounts = require('./includes/accounts');


mongoose.connect('mongodb://localhost');
var app = express();
app.set('views', path.join(__dirname, 'pages'));
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({ secret: 'shhsecret' }));
app.use(passport.initialize());
app.use(passport.session());

accounts.init(passport);
app.use('/', router);

var server = app.listen(8081, function ()
{
    var host = server.address().address;
    var port = server.address().port;
    console.log("Weapons mastery is running at http://%s:%s", host, port);
});
